import csv
import os
import time


# Global list to store transactions across various operations
Transaction_list_copy=[]

# Class for handling transaction additions
class Trans_addition:
    def __init__(self):
        msg="\n.................Transaction addition in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
    def add_transaction(self,Customer_list, trasaction_list):
        def trans_id():
            if trasaction_list:
                return trasaction_list[-1]["Transaction Id"] + 1
            else:
                return 1

        def new_transaction(cust_id, Date, Category):
            cust = next((customer for customer in Customer_list if customer['Customer Id'] == cust_id), None)
            if cust:
                Trans_id = trans_id()
                transaction = {'Transaction Id': Trans_id,"Customer Id": cust_id,"Date": Date,"sale_value":sale_value ,"Category": Category}
                trasaction_list.append(transaction)
                print("Id Generated With this Transaction is {}".format(Trans_id))
            else:
                return None

        id2 = int(input("Please Provide the Customer ID"))
        date = input("Please provide the Date (dd-mm-yyyy)")
        category = input("Please provide the Category")
        sale_value=int(input("Please Enter the sale value"))
        new_transaction(id2, date, category)
        print(trasaction_list)

class Trans_searching:
    def __init__(self):
        msg="\n.................Transaction Searching in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
    def search_transaction(self,trasaction_list):
        output_sales = []

        def string_to_find1(x):
            for i in trasaction_list:
                if (x.lower() in str(i["Transaction Id"]).lower() or x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Date"].lower() or x.lower() in i["Category "].lower()):
                    output_sales.append(i)
                else:
                    continue

        searching_string = input("Enter the String")
        string_to_find1(searching_string)
        print(output_sales)
class Trans_searching_byCustId:
    def __init__(self):
        msg="\n.................Transaction Search by means of Customer Details  in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
    def search_transaction_by_customer_id(self,Customer_list, trasaction_list):
        output_sales = []
        output_trans = []

        def string_to_find2(x):
            for i in Customer_list:
                if (x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Customer Name"].lower() or x.lower() in i["Customer Code"].lower() or x.lower() in i["Customer Phone"].lower()):
                    output_sales.append(i["Customer Id"])
            for j in trasaction_list:
                if j["Customer Id"] in output_sales:
                    output_trans.append(j)

        string_to_search = input("Enter the String")
        string_to_find2(string_to_search)
        print(output_trans)


class Trans_deletion:
    def __init__(self):
        msg="\n.................Transaction deletion in Process think well before Proceeding.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
    def delete_transaction(self,trasaction_list):
        new_Trans_list = []

        def deletion(x):
            for i in trasaction_list:
                if (int(i["Transaction Id"]) == int(x)):
                    continue
                else:
                    new_Trans_list.append(i)

        id3 = input('Enter the Transaction Id to be Removed')
        deletion(id3)
        print("Transaction Successfully Removed")
        print(new_Trans_list)

# Class for importing transactions from a CSV file
class TransactionFromFile:
    def __init__(self):
        msg = ".................Transaction import is in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)

    def transaction_from_file(self):
        def NewTransaction(customerId, date, category, value, transactionId):
            transaction = {
                "Date": date,
                'Transaction Id': transactionId,
                "Customer Id": customerId,
                "category ": category,
                "value": value,
            }
            Transaction_list_copy.append(transaction)
            print(f"Transaction ID {transactionId} generated for Customer ID {customerId}")
            print(f"Final Transaction list: {Transaction_list_copy}")

        path = input("Enter the Path location of the File: ")
        try:
            with open(path, mode='r', encoding='utf-8-sig') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    date = row['Date']
                    transactionId = row["Transaction Id"]
                    customerId = int(row['Customer Id'])
                    category = row['category']
                    value = int(row["value"])

                    existingCustomer = next(
                        (cust for cust in Transaction_list_copy if int(cust['Customer Id']) == customerId), None)

                    if existingCustomer:
                        newTransactionId = int(
                            max(Transaction_list_copy, key=lambda k: int(k['Transaction Id']))['Transaction Id']) + 1
                        NewTransaction(customerId, date, category, value, newTransactionId)
                    else:
                        NewTransaction(customerId, date, category, value, transactionId)
        except:
            print("Error Occurred. Please check the file path and format.")

# Class for saving transactions to a CSV file
class SaveTranscationToFile:
    def __init__(self):
        msg = ".................Saving Transaction File is in Process Please Follow the Required Steps.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)

    # Method to save the current list of transactions to a CSV file
    def save_to_csv(self):
        try:
            path = input("Enter the File Path")
            if os.path.exists(path):
                print(
                    "*************** Warning!!!!!!!!!!!!!!!! content of the file would be lost wanna Continue ????????????***************")
                ask = int(
                    input("Press 1 for Creating New File\n2. for Over writing the File\n3.Cancellation of Operation"))
                if (ask == 1):
                    path2 = input("Enter the Location in which you want the New File to be Saved")
                    path = path2
                    mode = "w"
                elif (ask == 2):
                    mode = "w"
                else:
                    print("operation Aborted")
                    return
            else:
                mode = "w"
            with open(path, mode, newline="") as f:
                columns = ["Transaction Id", "Customer Id", "Date", "value", "category "]
                z = csv.DictWriter(f, fieldnames=columns)

                if mode == "w":
                    z.writeheader()

                for i in Transaction_list_copy:
                    z.writerow(i)

            print("File Created")
        except:
            print(
                "*****************************************************************\nError Occured This May Be due to the Following Reasons\n1.Enter the Path without inverted Commas\n2.Enter the Valid Path\n3.You might Have entered a non integer value in Choices Option")
