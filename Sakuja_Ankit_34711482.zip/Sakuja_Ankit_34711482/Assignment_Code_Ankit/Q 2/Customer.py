import csv
import os
import time

# This list will hold a copy of the customer data.
Customer_list_copy=[]

# Class for adding new customers
class addition:
    def __init__(self):
        msg = ("\n.................Customer addition in Process.......................\n")
        for j in msg:
            print(j, end="")
            time.sleep(0.05)
    def add_customer(self,Customer_list):
        def id():
            if Customer_list:
                return Customer_list[-1]['Customer Id'] + 1
            else:
                return 1

        def new_customer(Cust_name, Cust_code="", Cust_phone=""):
            Cust_id = id()
            Cust_detail = {"Customer Id": Cust_id,"Customer Name": Cust_name,"Customer Code": Cust_code,"Customer Phone": Cust_phone}
            Customer_list.append(Cust_detail)
            print("The New Customer ID Generated is {}".format(Cust_id))

        name = input("Please input the Name(Required)")
        Code = input("Please input the PostCode(Optional)")
        Phone_no = input("Please input the Phone Number(Optional)")
        new_customer(name, Code, Phone_no)
        print(Customer_list)

class searching:
    def __init__(self):
        msg = "\n.................Customer searching in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)
    def search_customer(self,Customer_list):
        result = []

        def string_to_find(x):
            for i in Customer_list:
                if (x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Customer Name"].lower() or x.lower() in i["Customer Code"].lower() or x.lower() in i["Customer Phone"].lower()):
                    result.append(i)
                else:
                    continue

        searching_string = input("please Enter the String to be Searched")
        string_to_find(searching_string)
        print(result)

# Class for deleting customers
class deletion:
    def __init__(self):
        msg = ".................Customer deletion in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)
    def delete_customer(self,Customer_list, trasaction_list):
        new_Cust_list = []
        new_trans1_list = []

        def deletion(x):
            for i in Customer_list:
                if (int(i["Customer Id"]) == int(x)):
                    continue
                else:
                    new_Cust_list.append(i)
            for j in trasaction_list:
                for i in Customer_list:
                    if (int(j['Transaction Id']) == int(i["Customer Id"])):
                        new_trans1_list.append(j)
                    break

        id4 = input('Enter the Customer Id to be Removed')
        deletion(id4)
        print("Customer and Following Transaction Successfully Removed")
        print(new_Cust_list)
        print(new_trans1_list)


# Class for loading customers from a CSV file
class Customer_load:
    def __init__(self):
        msg = ".................Customer import is  in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)

    # Method to load customers from a file
    def load_cust(self):
        path=input("Enter the Path of the File")
        prev_id=[y["Customer Id"] for y in Customer_list_copy]
        try:
            with open(path,mode='r',newline='',encoding='utf-8-sig') as f:
                x=csv.DictReader(f)
                cust=list(x)

                for i in cust:
                    if(int(i['Customer Id']) not in prev_id):
                        Customer_list_copy.append(i)
                    else:
                        print("Customer Already Present for id {}".format(i["Customer Id"]))
            print(Customer_list_copy)
        except:
            print("****************************************************************\nError Occured This May Be due to the Following Reasons\n1.Enter the Path without inverted Commas\n2.Enter the Valid Path")

# Class for saving customers to a CSV file
class Save_to_file:
    def __init__(self):
        msg = ".................Customer File Saving  is in Process please Follow the Required Steps.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)

    # Method to save customer records to a file
    def Save_record_to_File(self):
        try:
            path=input("Enter the File Path")
            if os.path.exists(path):
                ask=int(input("Press 1 for Creating New File\n2. for Over writing the File\n3.Cancellation of Operation"))
                if(ask==1):
                    path2=input("Enter the Location in which you want the New File to be Saved")
                    path=path2
                    mode="w"
                elif(ask==2):
                    mode="w"
                else:
                    print("operation Aborted")
                    return
            else:
                mode="w"

            with open(path,mode,newline="") as f:
                columns=["Customer Id","Customer Name","Customer Code","Customer Phone"]
                z=csv.DictWriter(f,fieldnames=columns)

                if mode=="w":
                    z.writeheader()

                for i in Customer_list_copy:
                    z.writerow(i)

            print("File Created")
        except:
            print("*****************************************************************\nError Occured This May Be due to the Following Reasons\n1.Enter the Path without inverted Commas\n2.Enter the Valid Path\n3.You might Have entered a non integer value in Choices Option")

