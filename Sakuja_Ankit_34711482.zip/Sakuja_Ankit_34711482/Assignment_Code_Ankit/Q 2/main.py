# Import necessary modules and classes

from Customer import addition,searching,deletion,Customer_load,Save_to_file
from Transaction import Trans_addition,Trans_searching,Trans_deletion,Trans_searching_byCustId,TransactionFromFile,SaveTranscationToFile
import time
# Welcome message with instructions
msg="Hello! Welcome to Western Wholesale Pvt. ltd.\n....Presenting Our Newly Customised Menu....\nEnter the Following Number to Perform the Task Written\n1.Add New Customer\n2.Add New Transaction\n3.Search Customer\n4.Search Transaction\n5.Search Transaction Based on Customer Details\n6.Delete A Transaction\n7.Delete a Customer\n8.Exit from the Program\n9.Load Customers from CSV File\n10.To save the records in file\n11.Adding new Transactions from File\n12.Save transaction to File"

# Function to display exit message with a delay
def exit_msg_display(b):
    for i in b:
        print(i,end="")
        time.sleep(0.05)

# Function to handle user input and direct to the appropriate action
def Verification():
    global choice
    try:
        choice=int(input("\nEnter any number of your choice or 8 to Exit"))
    except:
        print("only integers are allowed")
        Verification()
    match(choice):
        case 1:
            cust_add=addition()
            cust_add.add_customer(Customer_data_list)
            Verification()
        case 2:
            trans_add=Trans_addition()
            trans_add.add_transaction(Customer_data_list,transaction_data_list)
            Verification()
        case 3:
            cust_search=searching()
            cust_search.search_customer(Customer_data_list)
            Verification()
        case 4:
            trans_search=Trans_searching()
            trans_search.search_transaction(transaction_data_list)
            Verification()
        case 5:
            trans_searchCustId=Trans_searching_byCustId()
            trans_searchCustId.search_transaction_by_customer_id(Customer_data_list,transaction_data_list)
            Verification()
        case 6:
            trans_del=Trans_deletion()
            trans_del.delete_transaction(transaction_data_list)
            Verification()
        case 7:
            Cust_del=deletion()
            Cust_del.delete_customer(Customer_data_list,transaction_data_list)
            Verification()
        case 8:
            exit_msg="Thanks for using Our Service!!! please Visit Again :) "
            exit_msg_display(exit_msg)
            exit()
        case 9:
            cust_load=Customer_load()
            cust_load.load_cust()
            Verification()
        case 10:
            Cust_save=Save_to_file()
            Cust_save.Save_record_to_File()
            Verification()
        case 11:
            Trans_load=TransactionFromFile()
            Trans_load.transaction_from_file()
            Verification()
        case 12:
            Trans_save=SaveTranscationToFile()
            Trans_save.save_to_csv()
            Verification()

# Function to display the initial message and trigger verification
def display_msg(a):
    for i in a:
        print(i,end="")
        time.sleep(0.05)
    Verification()

# Initialize empty lists to store customer and transaction data
Customer_data_list = []
transaction_data_list=[]

# Start the program by displaying the welcome message and then proceed to verification
display_msg(msg)