import time
# Class to handle customer addition
class addition:
# Constructor to display an introductory message for customer addition
    def __init__(self):
        msg = ("\n.................Customer addition in Process.......................\n")
        for j in msg:
            print(j, end="")
            time.sleep(0.05)
 # Method to add a customer to the Customer_list
    def add_customer(self,Customer_list):
    # Nested function to generate a new customer ID
        def id():
            if Customer_list:
                return Customer_list[-1]['Customer Id'] + 1
            else:
                return 1

    # Nested function to create a new customer dictionary and add it to the Customer_list
        def new_customer(Cust_name, Cust_code="", Cust_phone=""):
            Cust_id = id()
# customer detail dictionary
            Cust_detail = {"Customer Id": Cust_id,"Customer Name": Cust_name,"Customer Code": Cust_code,"Customer Phone": Cust_phone}
            Customer_list.append(Cust_detail)
            print("The New Customer ID Generated is {}".format(Cust_id))

# Take user inputs for the new customer details
        name = input("Please input the Name(Required)")
        Code = input("Please input the PostCode(Optional)")
        Phone_no = input("Please input the Phone Number(Optional)")
        new_customer(name, Code, Phone_no)
        print(Customer_list)

# Class to handle customer searching
class searching:
    def __init__(self):
        msg = "\n.................Customer searching in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)

    # Method to search for customers in the Customer_list
    def search_customer(self,Customer_list):
        result = []

        # Nested function to perform the search based on a given string
        def string_to_find(x):
            for i in Customer_list:
                if (x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Customer Name"].lower() or x.lower() in i["Customer Code"].lower() or x.lower() in i["Customer Phone"].lower()):
                    result.append(i)
                else:
                    continue

        searching_string = input("please Enter the String to be Searched")
        string_to_find(searching_string)
        print(result)

# Class to handle customer deletion
class deletion:
    def __init__(self):
        msg = ".................Customer deletion in Process.......................\n"
        for j in msg:
            print(j, end="")
            time.sleep(0.05)
     # Method to delete a customer from the Customer_list and their transactions from the transaction_list
    def delete_customer(self,Customer_list, trasaction_list):
        # Initialize a new list to hold remaining customers
        new_Cust_list = []
        #Initialize a new list to hold remaining transactions
        new_trans1_list = []

        def deletion(x):
            for i in Customer_list:
                if (int(i["Customer Id"]) == int(x)):
                    continue
                else:
                    new_Cust_list.append(i)
            for j in trasaction_list:
                for i in Customer_list:
                    if (int(j['Transaction Id']) == int(i["Customer Id"])):
                        new_trans1_list.append(j)
                    break

# Prompt user to enter the ID of the customer to be removed
        id4 = input('Enter the Customer Id to be Removed')
        deletion(id4)
        print("Customer and Following Transaction Successfully Removed")
        print(new_Cust_list)
        print(new_trans1_list)
