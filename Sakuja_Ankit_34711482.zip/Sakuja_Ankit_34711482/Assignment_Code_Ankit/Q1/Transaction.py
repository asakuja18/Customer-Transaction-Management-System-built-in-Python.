import time

# Class for handling the addition of transactions
class Trans_addition:
    def __init__(self):
        msg="\n.................Transaction addition in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)

    # Method to add a transaction to the transaction list
    def add_transaction(self,Customer_list, trans_list):
        def trans_id():
            if trans_list:
                return trans_list[-1]["Transaction Id"] + 1
            else:
                return 1

        def new_transaction(cust_id, Date, Category):
            cust = next((customer for customer in Customer_list if customer['Customer Id'] == cust_id), None)
            if cust:
                Trans_id = trans_id()
                transaction = {'Transaction Id': Trans_id,"Customer Id": cust_id,"Date": Date,"Category ": Category,"sale_Value":sale_Value}
                trans_list.append(transaction)
                print("Customer id with this transaction ID is {}".format(Trans_id))
            else:
                return None

        # Input prompts for the new transaction
        id2 = int(input("Please Provide the Customer ID"))
        date = input("Please provide the Date (dd-mm-yyyy)")
        category = input("Please provide the Category")
        sale_Value =int(input("Please provide the value"))
        new_transaction(id2, date, category)
        print(trans_list)

# Class for handling transaction searching
class Trans_searching:
    def __init__(self):
        msg="\n.................Transaction Searching in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
 # Method to search for transactions within the transaction list
    def search_transaction(self,trasaction_list):
        output_sales = []

        def string_to_find1(x):
            for i in trasaction_list:
                if (x.lower() in str(i["Transaction Id"]).lower() or x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Date"].lower() or x.lower() in i["Category "].lower()):
                    output_sales.append(i)
                else:
                    continue

        searching_string = input("Enter the String")
        string_to_find1(searching_string)
        print(output_sales)

# Class for transaction search based on customer details
class Trans_searching_byCustId:
    def __init__(self):
        msg="\n.................Transaction Search by means of Customer Details  in Process.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
# Method to search transactions by customer details
    def search_transaction_by_customer_id(self,Customer_list, transaction_list):
        output_sales = []
        output_trans = []

        def string_to_find2(x):
            # Check if search string x is in any customer detail
            for i in Customer_list:
                if (x.lower() in str(i["Customer Id"]).lower() or x.lower() in i["Customer Name"].lower() or x.lower() in i["Customer Code"].lower() or x.lower() in i["Customer Phone"].lower()):
                    output_sales.append(i["Customer Id"])
            for j in transaction_list:
                if j["Customer Id"] in output_sales:
                    output_trans.append(j)

        string_to_search = input("Enter the String")
        string_to_find2(string_to_search)
        print(output_trans)

class Trans_deletion:
    def __init__(self):
        msg="\n.................Transaction deletion in Process think twice before Proceeding.......................\n"
        for j in msg:
            print(j,end="")
            time.sleep(0.05)
    def delete_transaction(self,trans_list):
        new_Trans_list = []

        def deletion(x):
            for i in trans_list:
                if (int(i["Transaction Id"]) == int(x)):
                    continue
                else:
                    new_Trans_list.append(i)

        id3 = input('Enter the Transaction Id to be Removed')
        deletion(id3)
        print("Transaction Removed Successfully ")
        print(new_Trans_list)
