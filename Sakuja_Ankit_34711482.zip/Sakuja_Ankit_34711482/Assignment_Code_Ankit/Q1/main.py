# Import necessary classes from the Customer module
from Customer import addition,searching,deletion
# Import necessary classes from the Transaction module
from Transaction import Trans_addition,Trans_searching,Trans_deletion,Trans_searching_byCustId
# Import the time module for delay effects in displaying messages
import time
# Define a function to display messages with a typewriter-like effect
def display_msg(a):
    for i in a:
        print(i,end="")
        time.sleep(0.05)
# Define a welcome message that will be displayed to the user
msg="Hello! Welcome to Western Wholesale Pvt. ltd.\n....Presenting Our Newly Customised Menu....\nEnter the Following Number to Perform the Task Written\n1.Add New Customer\n2.Add New Transaction\n3.Search Customer\n4.Search Transaction\n5.Search Transaction Based on Customer Details\n6.Delete A Transaction\n7.Delete a Customer\n8.Exit from the Program"
# Define a function to display the exit message with a typewriter-like effect
def exit_msg_display(b):
    for i in b:
        print(i,end="")
        time.sleep(0.05)
# Define a function to handle the input verification and user choice
def Verification():
# Declare 'choice' as a global variable to use it outside of the function if necessary
    global choice
    try:
        choice=int(input("\nEnter any number of your choice or 8 to Exit"))
    except:
        print("only integers are allowed")
# Recursively call the Verification function to allow the user to try again
        Verification()
# Match the user's choice to the corresponding task
    match(choice):
        case 1:
            cust_add=addition()
            cust_add.add_customer(Customer_data_list)
            Verification()
        case 2:
            trans_add=Trans_addition()
            trans_add.add_transaction(Customer_data_list,transaction_data_list)
            Verification()
        case 3:
            cust_search=searching()
            cust_search.search_customer(Customer_data_list)
            Verification()
        case 4:
            trans_search=Trans_searching()
            trans_search.search_transaction(transaction_data_list)
            Verification()
        case 5:
            trans_searchCustId=Trans_searching_byCustId()
            trans_searchCustId.search_transaction_by_customer_id(Customer_data_list,transaction_data_list)
            Verification()
        case 6:
            trans_del=Trans_deletion()
            trans_del.delete_transaction(transaction_data_list)
            Verification()
        case 7:
            Cust_del=deletion()
            Cust_del.delete_customer(Customer_data_list,transaction_data_list)
            Verification()
# Exit the program
        case 8:
            exit_msg="Thanks for using Our Service!!! please Visit Again :) "
            exit_msg_display(exit_msg)
            exit()

# Initialize lists to store customer and transaction data
Customer_data_list = []
transaction_data_list=[]
# Display the welcome message and start the verification process
display_msg(msg)
Verification()